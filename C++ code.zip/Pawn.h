#pragma once
#include "Piece.h"

class Pawn : public Piece {
public:
    Pawn(Position p, Colour c, Board* b);
    bool hasMoved = false;
    bool isLegal(Position dest) override;
    char draw() override;
    int getTextureID() override
    {
        if (color == cwhite)
            return 0;
        else
            return 1;
    }
};

