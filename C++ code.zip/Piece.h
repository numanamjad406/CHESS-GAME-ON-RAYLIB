#pragma once
#include "Position.h"
#include "Colour.h"
class Board;
class Piece
{
protected:
	Position pos;
	Colour color;
	Board* board;
public:
	Piece(Position p, Colour c, Board* b);
	virtual ~Piece();
	Colour getcolor();
	Position getposition();
	void setposition(Position p);
	virtual bool isLegal(Position destination) = 0;
	virtual char draw() = 0;
	static bool isHorizontal(Position src, Position dest);
	static bool isVertical(Position src, Position dest);
	static bool isDiagonal(Position src, Position dest);

	static bool isHorizontalpathclear(Position src, Position dest, Board* b);
	static bool isVerticalpathclear(Position src, Position dest, Board* b);
	static bool isDiagonalpathclear(Position src, Position dest, Board* b);
	virtual int getTextureID() = 0;

};