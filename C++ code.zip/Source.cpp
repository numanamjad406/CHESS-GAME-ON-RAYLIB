#include <iostream>
#include <raylib.h>
#include "Board.h"
#include "Pawn.h"
#include "Rook.h"
#include "Knight.h"
#include "Bishop.h"
#include "Queen.h"
#include "King.h"
#include "Player.h"
#include "Game.h"
#include "TextureManager.h"

using namespace std;

int main()
{
    string name1, name2;

    cout << "Enter WHITE player name: ";
    cin >> name1;

    cout << "Enter BLACK player name: ";
    cin >> name2;
    InitWindow(1600, 900, "Chess");
    SetTargetFPS(60);

    TextureManager::LoadTextures();

    

    Game* game = Game::getInstance();
    game->setPlayerNames(name1, name2);

    while (!WindowShouldClose())
    {
        BeginDrawing();

       
        ClearBackground(DARKGRAY);

        game->startgame();
        EndDrawing();
    }

    TextureManager::UnloadTextures();
    CloseWindow();

    return 0;
}