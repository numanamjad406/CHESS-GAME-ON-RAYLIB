#include "King.h"
#include <cmath>

King::King(Position p, Colour c, Board* b)
    : Piece(p, c, b){}

char King::draw()
{
    if (color == cwhite)
    {
        return 'K';
    }
    else
        return 'k';

}

bool King::isLegal(Position dest)
{
    int dr = abs(dest.row - pos.row);
    int dc = abs(dest.col - pos.col);
    return (dr <= 1 and dc <= 1) and (dr + dc > 0);
}