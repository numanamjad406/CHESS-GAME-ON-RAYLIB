#pragma once
#include <raylib.h>

class TextureManager
{
public:
    static Texture2D textures[12];

    static void LoadTextures();


    static Texture2D Get(int id);

    static void UnloadTextures();
};