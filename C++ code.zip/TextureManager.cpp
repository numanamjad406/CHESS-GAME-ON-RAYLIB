#include "TextureManager.h"

Texture2D TextureManager::textures[12];

void TextureManager::LoadTextures()
{
    textures[0] = LoadTexture("w_pawn.png"); 
    textures[1] = LoadTexture("b_pawn.png");

    textures[2] = LoadTexture("w_rook.png");
    textures[3] = LoadTexture("b_rook.png");

    textures[4] = LoadTexture("w_knight.png");
    textures[5] = LoadTexture("b_knight.png");

    textures[6] = LoadTexture("w_bishop.png");
    textures[7] = LoadTexture("b_bishop.png");

    textures[8] = LoadTexture("w_queen.png");
    textures[9] = LoadTexture("b_queen.png");

    textures[10] = LoadTexture("w_king.png");
    textures[11] = LoadTexture("b_king.png");
}
Texture2D TextureManager::Get(int id)
{
    return textures[id];
}

void TextureManager::UnloadTextures()
{
    for (int i = 0; i < 12; i++)
    {
        UnloadTexture(textures[i]);
    }
}