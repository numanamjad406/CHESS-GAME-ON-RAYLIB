#include "Rook.h"
#include "Board.h"
Rook::Rook(Position p, Colour c, Board* b) : Piece(p, c, b)
{

}
char Rook::draw()
{
	if (color == cwhite)
	{
		return 'R';
	}
	else
		return 'r';
}
bool Rook::isLegal(Position dest)
{
	if (isHorizontal(pos, dest))
	{
		return isHorizontalpathclear(pos, dest, board);
	}

	if (isVertical(pos, dest))
	{
		return isVerticalpathclear(pos, dest, board);
	}

	return false;
}