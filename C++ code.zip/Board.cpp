#include "Board.h"
#include <iostream>
#include "raylib.h"
#include "TextureManager.h"
#include <fstream>
#include "Position.h"

using namespace std;

Board::Board()
{
    init();
}

Board::~Board()
{

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            if (grid[r][c] != nullptr)
            {
                delete grid[r][c];
            }
        }
    }
}

Piece* Board::pieceAt(Position p)
{

    if (p.row < 0 or p.row > 7 or p.col < 0 or p.col > 7)
    {
        return nullptr;
    }
    return grid[p.row][p.col];
}

void Board::init()
{

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            grid[r][c] = nullptr;
        }
    }


    for (int c = 0; c < 8; c++)
    {
        grid[6][c] = new Pawn(Position{ 6, c }, cwhite, this);
        grid[1][c] = new Pawn(Position{ 1, c }, cblack, this);
    }


    grid[7][0] = new Rook(Position{ 7,0 }, cwhite, this);
    grid[7][1] = new Knight(Position{ 7,1 }, cwhite, this);
    grid[7][2] = new Bishop(Position{ 7,2 }, cwhite, this);
    grid[7][3] = new Queen(Position{ 7,3 }, cwhite, this);
    grid[7][4] = new King(Position{ 7,4 }, cwhite, this);
    grid[7][5] = new Bishop(Position{ 7,5 }, cwhite, this);
    grid[7][6] = new Knight(Position{ 7,6 }, cwhite, this);
    grid[7][7] = new Rook(Position{ 7,7 }, cwhite, this);


    grid[0][0] = new Rook(Position{ 0,0 }, cblack, this);
    grid[0][1] = new Knight(Position{ 0,1 }, cblack, this);
    grid[0][2] = new Bishop(Position{ 0,2 }, cblack, this);
    grid[0][3] = new Queen(Position{ 0,3 }, cblack, this);
    grid[0][4] = new King(Position{ 0,4 }, cblack, this);
    grid[0][5] = new Bishop(Position{ 0,5 }, cblack, this);
    grid[0][6] = new Knight(Position{ 0,6 }, cblack, this);
    grid[0][7] = new Rook(Position{ 0,7 }, cblack, this);
}

void Board::displayBoard()
{
    cout << endl;
    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            if (grid[r][c] != nullptr)
            {
                cout << grid[r][c]->draw() << " ";
            }
            else
                cout << "- ";
        }
        cout << endl;
    }
}


bool Board::update(Position src, Position dest)
{
    Piece* p = grid[src.row][src.col];

    if (!p) 
    {
        return false;
    }
    if (grid[dest.row][dest.col] != nullptr)
    {
        if (dynamic_cast<King*>(grid[dest.row][dest.col]))
        {
            delete grid[dest.row][dest.col];
            grid[dest.row][dest.col] = nullptr;

            grid[dest.row][dest.col] = p;
            grid[src.row][src.col] = nullptr;

            p->setposition(dest);

            return true;
        }

        delete grid[dest.row][dest.col];
    }

    grid[dest.row][dest.col] = p;
    grid[src.row][src.col] = nullptr;
    p->setposition(dest);

    return false;
}
bool Board::validateSource(Position src, Player current)
{

    Piece* p = pieceAt(src);
    if (!p)
    {
        return false;
    }
    return p->getcolor() == current.getcolor();
}

bool Board::validateDestination(Position dest, Player current)
{
    Piece* p = pieceAt(dest);
    if (!p)
    {
        return true;
    }
    return p->getcolor() != current.getcolor();
}


void Board::drawPieces()
{
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            Piece* p = grid[i][j];

            if (p)
            {
                int id = p->getTextureID();
                Texture2D tex = TextureManager::Get(id);

                int x = 100 + j * 100;
                int y = 50 + i * 100;

                DrawTexturePro(tex,Rectangle{ 0, 0, (float)tex.width, (float)tex.height },
                    Rectangle{ (float)x, (float)y, 100, 100 }, Vector2{ 0, 0 },0.0f,WHITE );
            }
        }
    }
}

void Board::saveGame(const string& filename)
{
    ofstream rdr(filename);

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            Piece* p = grid[r][c];

            if (p == nullptr)
            {
                rdr << "- ";
            }
            else
            {
                rdr << p->draw() << " ";
            }
        }
        rdr << endl;
    }

    rdr.close();
}
void Board::loadGame(const string& filename)
{
    ifstream rdr(filename);

    string symbol;

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            rdr>> symbol;
            if (grid[r][c] != nullptr)
            {
                delete grid[r][c];
                grid[r][c] = nullptr;
            }

            if (symbol == "-")
                continue;

            char ch = symbol[0];

            switch (ch)
            {
            case 'p':
                grid[r][c] = new Pawn({ r,c }, cblack, this); 
                break;
            case 'P':
                grid[r][c] = new Pawn({ r,c }, cwhite, this); break;

            case 'r':
                
                grid[r][c] = new Rook({ r,c }, cblack, this); break;
            case 'R': grid[r][c] = new Rook({ r,c }, cwhite, this); break;

            case 'n': grid[r][c] = new Knight({ r,c }, cblack, this); break;
            case 'N': grid[r][c] = new Knight({ r,c }, cwhite, this); break;

            case 'b': grid[r][c] = new Bishop({ r,c }, cblack, this); break;
            case 'B': grid[r][c] = new Bishop({ r,c }, cwhite, this); break;

            case 'q': grid[r][c] = new Queen({ r,c }, cblack, this); break;
            case 'Q': grid[r][c] = new Queen({ r,c }, cwhite, this); break;

            case 'k': grid[r][c] = new King({ r,c }, cblack, this); break;
            case 'K': grid[r][c] = new King({ r,c }, cwhite, this); break;
            }
        }
    }

    rdr.close();
}

string Board::getState()
{
    string s = "";

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            if (grid[r][c] == nullptr)
                s += '-';
            else
                s += grid[r][c]->draw();
        }
    }
    return s;
}

void Board::setState(string s)
{
    int k = 0;

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            if (grid[r][c])
            {
                delete grid[r][c];
                grid[r][c] = nullptr;
            }

            char ch = s[k++];

            if (ch == '-')
                continue;

            if (ch == 'P') grid[r][c] = new Pawn({ r,c }, cwhite, this);
            if (ch == 'p') grid[r][c] = new Pawn({ r,c }, cblack, this);

            if (ch == 'R') grid[r][c] = new Rook({ r,c }, cwhite, this);
            if (ch == 'r') grid[r][c] = new Rook({ r,c }, cblack, this);

            if (ch == 'N') grid[r][c] = new Knight({ r,c }, cwhite, this);
            if (ch == 'n') grid[r][c] = new Knight({ r,c }, cblack, this);

            if (ch == 'B') grid[r][c] = new Bishop({ r,c }, cwhite, this);
            if (ch == 'b') grid[r][c] = new Bishop({ r,c }, cblack, this);

            if (ch == 'Q') grid[r][c] = new Queen({ r,c }, cwhite, this);
            if (ch == 'q') grid[r][c] = new Queen({ r,c }, cblack, this);

            if (ch == 'K') grid[r][c] = new King({ r,c }, cwhite, this);
            if (ch == 'k') grid[r][c] = new King({ r,c }, cblack, this);
        }
    }
}

