#pragma once
#include <raylib.h>
#include "Board.h"   
#include "Player.h"
#include <vector>
enum GameState
{
    MENU,
    PLAYING,
    CHECK,
    CHECKMATE,
    STALEMATE
};


class Game
{
    static Game* instance;
    Board board;

    Position selected;
    bool isSelected = false;

    Player* white;
    Player* black;
    Player* currentPlayer;

    Game();

public:
    int replayIndex = 0;
    bool replayMode = false;
    GameState state;
    vector<string> history;
    vector<string> redo;


    void clearHighlights();
    void drawHighlights();

    void calculateHighlights(Position p);
    vector<Position> highlights;
    string message;
    static Game* getInstance();

    void displayBoard();
    void startgame();
    void handleInput();
    Position findKing(Player* player);

    bool isKingInCheck(Player* player);
    bool hasLegalMoves(Player* player);

    void updateGameState();

    void redoMove();
    void undo();
    void setPlayerNames(string n1, string n2);
    bool isMoveSafe(Position src, Position des, Player* player);

};