#include "Piece.h"
#include "Board.h"
#include <cmath>

Piece::Piece(Position p, Colour c, Board* b)
{
    pos = p;
    color = c;
    board = b;
}

Piece::~Piece() {}

Colour Piece::getcolor()
{
    return color;
}

Position Piece::getposition()
{
    return pos;

}

void Piece::setposition(Position p)
{
    pos = p;
}


bool Piece::isHorizontal(Position src, Position dest)
{
    return src.row == dest.row and src.col != dest.col;

}

bool Piece::isVertical(Position src, Position dest)
{
    return src.row != dest.row and src.col == dest.col;

}

bool Piece::isDiagonal(Position src, Position dest)
{
    return abs(src.row - dest.row) == abs(src.col - dest.col);

}

bool Piece::isHorizontalpathclear(Position src, Position dest, Board* b)
{
    if (src.col < dest.col)
    {
        for (int c = src.col + 1; c < dest.col; c++)
        {
            if (b->pieceAt(Position(src.row, c)) != nullptr)
                return false;
        }
    }
    else
    {
        for (int c = src.col - 1; c > dest.col; c--)
        {
            if (b->pieceAt(Position(src.row, c)) != nullptr)
                return false;
        }
    }

    return true;
}

bool Piece::isVerticalpathclear(Position src, Position dest, Board* b)
{
    if (src.row < dest.row)
    {
        for (int r = src.row + 1; r < dest.row; r++)
        {
            if (b->pieceAt(Position(r, src.col)) != nullptr)
                return false;
        }
    }
    else
    {
        for (int r = src.row - 1; r > dest.row; r--)
        {
            if (b->pieceAt(Position(r, src.col)) != nullptr)
                return false;
        }
    }

    return true;
}
bool Piece::isDiagonalpathclear(Position src, Position dest, Board* b)
{
    int r = src.row;
    int c = src.col;

    if (dest.row > src.row)
    {
        r++;
    }
    else
    {
        r--;
    }

    if (dest.col > src.col)
    {
        c++;
    }
    else
    {
        c--;
    }

    while (r != dest.row and c != dest.col)
    {
        if (b->pieceAt(Position(r, c)) != nullptr)
        {
            return false;
        }

        if (dest.row > src.row)
        {
            r++;
        }
        else
        {
            r--;
        }

        if (dest.col > src.col)
        {
            c++;
        }
        else
        {
            c--;
        }
    }

    return true;
}