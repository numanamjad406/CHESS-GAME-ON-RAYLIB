#include "Knight.h"
#include <cmath>

Knight::Knight(Position p, Colour c, Board* b)
	: Piece(p, c, b) {}
char Knight::draw()
{
	if (color == cwhite)
	{
		return 'N';
	}
	else
		return 'n';
}

bool Knight::isLegal(Position dest)
{
	int dr = abs(dest.row - pos.row);
	int dc = abs(dest.col - pos.col);

	return (dr == 2 and dc == 1) or
		(dr == 1 and dc == 2);
}