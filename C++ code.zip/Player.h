#pragma once
#include <string>
#include "Colour.h"
using namespace std;
class Player
{
	string name;
	Colour color;

public:
	Player(string n = "", Colour c = cwhite);
	string getname();
	Colour getcolor();

};