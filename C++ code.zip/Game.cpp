#include "Game.h"
#include "Board.h"
#include "raylib.h"
#include "Pawn.h"

Game* Game::instance = nullptr;
Game* Game::getInstance()
{
    if (!instance)
    {
        instance = new Game();
    }
    return instance;
}

void Game::displayBoard()
{
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if ((i + j) % 2 == 0)
            {
                DrawRectangle(100 + j * 100, 50 + i * 100, 100, 100, GOLD);
            }
            else
                DrawRectangle(100 + j * 100, 50 + i * 100, 100, 100, WHITE);
        }
    }
}
void Game::handleInput()
{
    if (replayMode)
    {

        if (IsKeyPressed(KEY_RIGHT))
        {
            if (replayIndex < history.size() - 1)
            {
                replayIndex++;
                board.setState(history[replayIndex]);
            }
        }


        if (IsKeyPressed(KEY_LEFT))
        {
            if (replayIndex > 0)
            {
                replayIndex--;
                board.setState(history[replayIndex]);
            }
        }

        return;
    }
    if (state == MENU)
    {
        if (IsKeyPressed(KEY_N))
        {
            board.init();
            history.clear();
            history.push_back(board.getState());

            replayMode = false;
            state = PLAYING;
        }

        if (IsKeyPressed(KEY_L))
        {
            board.loadGame("saves.txt");
            state = PLAYING;
        }

        return;
    }
    if (IsKeyPressed(KEY_S))
    {
        board.saveGame("saves.txt");
        message = "GAME SAVED!";
    }

    if (IsKeyPressed(KEY_L))
    {
        board.loadGame("saves.txt");
        message = "GAME LOADED  ";
        isSelected = false;
        clearHighlights();
    }
    if (IsKeyPressed(KEY_U))
    {
        undo();
        isSelected = false;
        clearHighlights();
    }

    if (IsKeyPressed(KEY_R))
    {
        redoMove();
        isSelected = false;
        clearHighlights();

    }
    if (!IsMouseButtonPressed(MOUSE_LEFT_BUTTON))
    {
        return;
    }

    Vector2 mouse = GetMousePosition();

    int col = (int)((mouse.x - 100) / 100);
    int row = (int)((mouse.y - 50) / 100);


    if (row < 0 || row > 7 || col < 0 || col > 7)
    {
        message = "INVALID CLICK";
        isSelected = false;
        clearHighlights();
        return;
    }

    Position clicked(row, col);

    if (!isSelected)
    {
        Piece* p = board.pieceAt(clicked);

        if (p == nullptr)
        {
            message = "NO PIECE THERE";
            return;
        }

        if (p->getcolor() != currentPlayer->getcolor())
        {
            message = "NOT YOUR PIECE";
            return;
        }

        selected = clicked;
        isSelected = true;

        message = "PIECE SELECTED";

        calculateHighlights(clicked);


        return;
    }


    Piece* p = board.pieceAt(selected);

    if (p == nullptr)
    {
        message = "ERROR: NO PIECE!";
        isSelected = false;
        clearHighlights();
        return;
    }


    if (p->isLegal(clicked) &&
        board.validateDestination(clicked, *currentPlayer) &&
        isMoveSafe(selected, clicked, currentPlayer))
    {
        history.push_back(board.getState());
        redo.clear();

        Piece* movedPiece = board.pieceAt(selected);
        Pawn* pawn = dynamic_cast<Pawn*>(movedPiece);
        if (pawn) pawn->hasMoved = true;


        bool kingCaptured = board.update(selected, clicked);

        if (kingCaptured)
        {
            state = CHECKMATE;

            message = (currentPlayer == white) ? "WHITE WINS (KING CAPTURED)"
                : "BLACK WINS (KING CAPTURED)";
            replayMode = true;
            replayIndex = 0;
            board.setState(history[0]);


            isSelected = false;
            clearHighlights();
            currentPlayer = white;
            return;
        }
        updateGameState();

        if (state == PLAYING || state == CHECK)
        {
            if (currentPlayer == white)
            {
                currentPlayer = black;
                message = "BLACK TURN";
            }
            else
            {
                currentPlayer = white;
                message = "WHITE TURN";
            }
        }
    }
    else
    {
        message = "ILLEGAL MOVE!";
    }

    isSelected = false;
    clearHighlights();
}

Game::Game()
{
    white = new Player("White", cwhite);
    black = new Player("Black", cblack);

    currentPlayer = white;


    state = MENU;

    message = "WHITE TURN";
}
void Game::clearHighlights()
{
    highlights.clear();
}
void Game::calculateHighlights(Position p)
{
    highlights.clear();

    Piece* piece = board.pieceAt(p);
    if (!piece)
    {
        return;
    }

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            Position dest(r, c);


            if (dest.row == p.row && dest.col == p.col)
            {
                continue;
            }


            if (piece->isLegal(dest))
            {
                if (board.validateDestination(dest, *currentPlayer))
                {
                    if (isMoveSafe(p, dest, currentPlayer))  
                    {
                        highlights.push_back(dest);
                    }
                }
            }
        }
    }
}
void Game::startgame()
{


    handleInput();
    if (state == MENU)
    {
        ClearBackground(BLACK);


        DrawText("CHESS GAME", 520, 120, 80, GOLD);
        DrawText("OOP PROJECT", 640, 210, 30, GOLD);



        DrawText("PRESS N - NEW GAME", 600, 380, 30, GOLD);
        DrawText("PRESS L - LOAD GAME", 600, 440, 30, GOLD);

        DrawText("PRESS U - UNDO", 600, 500, 25, GOLD);
        DrawText("PRESS R - REDO", 600, 540, 25, GOLD);

        DrawText("ENJOY THE GAME!", 650, 650, 25, GOLD);

        return;
    }
    displayBoard();
    drawHighlights();
    board.drawPieces();

    DrawRectangle(1150, 50, 400, 800, Fade(BLACK, 0.85));
    DrawRectangleLines(1150, 50, 400, 800, GRAY);


    DrawText("CHESS GAME", 1230, 80, 30, GOLD);
    DrawLine(1170, 120, 1520, 120, GRAY);


    DrawText("Current Turn", 1250, 140, 20, WHITE);

    if (currentPlayer->getcolor() == cwhite)
    {
        DrawText("WHITE", 1280, 170, 35, GOLD);
    }
    else
        DrawText("BLACK", 1280, 170, 35, GOLD);


    DrawLine(1170, 220, 1520, 220, GRAY);

    DrawText("Status", 1300, 240, 20, WHITE);


    char messageText[128] = { 0 };
    for (int i = 0; i < message.size() && i < 127; i++)
    {
        messageText[i] = message[i];
    }

    DrawText(messageText, 1250, 270, 28, GREEN);


    DrawRectangle(1180, 330, 340, 70, Fade(GRAY, 0.2));

    DrawText("Player 1 (White)", 1220, 340, 18, GOLD);


    char p1[50] = { 0 };
    string n1 = white->getname();
    for (int i = 0; i < n1.size(); i++)
    {
        p1[i] = n1[i];
    }

    DrawText(p1, 1250, 365, 22, WHITE);

    DrawRectangle(1180, 420, 340, 70, Fade(GRAY, 0.2));

    DrawText("Player 2 (Black)", 1220, 430, 18, GOLD);

    char p2[50] = { 0 };
    string n2 = black->getname();
    for (int i = 0; i < n2.size(); i++) p2[i] = n2[i];

    DrawText(p2, 1250, 455, 22, WHITE);

    DrawLine(1170, 520, 1520, 520, GRAY);

    DrawText("[S] Save   [L] Load", 1200, 550, 18, GRAY);
    DrawText("[U] Undo   [R] Redo", 1200, 580, 18, GRAY);
    DrawText("[left or right arrow key] Replay", 1200, 610, 18, GRAY);



    if (state == CHECK)
    {
        DrawText("CHECK!", 600, 10, 40, BLACK);
    }

    if (state == CHECKMATE)
    {
        DrawText("CHECKMATE!", 520, 10, 50, BLACK);
    }

    if (state == STALEMATE)
    {
        DrawText("STALEMATE!", 520, 10, 50, BLACK);
    }
}

void Game::drawHighlights()
{
    for (auto h : highlights)
    {
        int x = 100 + h.col * 100;
        int y = 50 + h.row * 100;

        DrawRectangle(x, y, 100, 100, Color{ 0, 255, 0, 80 });
    }
}

Position Game::findKing(Player* player)
{
    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            Piece* p = board.pieceAt({ r, c });

            if (p && dynamic_cast<King*>(p))
            {
                if (p->getcolor() == player->getcolor())
                    return { r, c };
            }
        }
    }

    return { -1, -1 };
}

bool Game::isKingInCheck(Player* player)
{
    Position king = findKing(player);

    if (king.row < 0 || king.col < 0)
    {
        return false;
    }

    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            Piece* p = board.pieceAt({ r, c });

            if (p && p->getcolor() != player->getcolor())
            {

                if (p->isLegal(king))
                {
                    return true;
                }
            }
        }
    }

    return false;
}

bool Game::hasLegalMoves(Player* player)
{
    for (int r = 0; r < 8; r++)
    {
        for (int c = 0; c < 8; c++)
        {
            Piece* p = board.pieceAt({ r, c });

            if (p && p->getcolor() == player->getcolor())
            {
                for (int r2 = 0; r2 < 8; r2++)
                {
                    for (int c2 = 0; c2 < 8; c2++)
                    {
                        Position dest{ r2, c2 };

                        if (p->isLegal(dest) &&
                            board.validateDestination(dest, *player) &&
                            isMoveSafe({ r, c }, dest, player))
                        {
                            return true;
                        }

                    }
                }
            }
        }
    }
    return false;
}
void Game::updateGameState()
{
    if (state == CHECKMATE)
    {
        return;
    }

    Player* enemy = (currentPlayer == white) ? black : white;

    bool check = isKingInCheck(enemy);
    bool moves = hasLegalMoves(enemy);

    if (check && !moves)
    {
        state = CHECKMATE;
        message = "CHECKMATE!";
        return;
    }

    if (!check && !moves)
    {
        state = STALEMATE;
        message = "STALEMATE!";
        return;
    }

    if (check)
    {
        state = CHECK;
        message = "CHECK!";
        return;
    }

    state = PLAYING;
}

void Game::undo()
{
    if (history.size() <= 1) return;

    redo.push_back(board.getState());
    history.pop_back();
    board.setState(history.back());

    message = "UNDO";
}

void Game::redoMove()
{
    if (redo.empty())
        return;

    history.push_back(board.getState());

    board.setState(redo.back());
    redo.pop_back();

    message = "REDO";
}


void Game::setPlayerNames(string n1, string n2)
{
    delete white;
    delete black;
    white = new Player(n1, cwhite);
    black = new Player(n2, cblack);

    currentPlayer = white;
}


bool Game::isMoveSafe(Position s, Position d, Player* player)
{
    Piece* moving = board.pieceAt(s);
    if (!moving) return false;

    Piece* captured = board.pieceAt(d);


    board.grid[d.row][d.col] = moving;
    board.grid[s.row][s.col] = nullptr;
    moving->setposition(d);

    bool inCheck = isKingInCheck(player);


    board.grid[s.row][s.col] = moving;
    board.grid[d.row][d.col] = captured;
    moving->setposition(s);

    return !inCheck;
}