#pragma once
#include "Piece.h"
class Bishop :public Piece
{

public:
    Bishop(Position p, Colour c, Board* b);

    bool isLegal(Position dest) override;
    char draw() override;
    int getTextureID() override
    {
        if (color == cwhite)
            return 6;
        else
            return 7;
    }
};

