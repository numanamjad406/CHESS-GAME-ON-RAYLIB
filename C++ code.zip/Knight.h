#pragma once
#include "Piece.h"
class Knight :public Piece
{
public:
	Knight(Position p, Colour c, Board* b);
	bool isLegal(Position dest) override;
	char draw() override;
	int getTextureID() override
	{
		if (color == cwhite)
			return 4;
	    else 
			return 5;
	}
};

