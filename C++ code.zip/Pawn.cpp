#include "Pawn.h"
#include "Board.h"
#include <cmath>

Pawn::Pawn(Position p, Colour c, Board* b)
    : Piece(p, c, b) 
{
    hasMoved = false;
}

char Pawn::draw()
{
    if (color == cwhite)
    {
        return 'P';
    }
    else
    {
        return 'p';
    }
}

bool Pawn::isLegal(Position dest)
{
    if (dest.row < 0 || dest.row > 7 || dest.col < 0 || dest.col > 7)
        return false;
    int direction;

    if (color == cwhite)
    {
        direction = -1;
    }
    else
    {
        direction = 1;
    }

    if (dest.col == pos.col)
    {
       
        if (dest.row == pos.row + direction)
        {
            if (board->pieceAt(dest) == nullptr)
            {
                return true;
            }
        }

        if (!hasMoved && dest.row == pos.row + 2 * direction)
        {
            Position middle(pos.row + direction, pos.col);
            if (board->pieceAt(middle) == nullptr && board->pieceAt(dest) == nullptr)
            {
                return true;
            }
        }
    }

    if (abs(dest.col - pos.col) == 1)
    {
        if (dest.row == pos.row + direction)
        {
            if (board->pieceAt(dest) != nullptr)
            {
                if (board->pieceAt(dest)->getcolor() != color)
                {
                    return true;
                }
            }
        }
    }

    return false;
}