#include "Bishop.h"
#include "Board.h"
Bishop::Bishop(Position p, Colour c, Board* b)
	: Piece(p, c, b) {}


char Bishop::draw()
{
	if (color == cwhite)
	{
		return 'B';
	}
	else
		return 'b';
}
bool Bishop::isLegal(Position dest)
{
	if (isDiagonal(pos, dest))
	{
		return isDiagonalpathclear(pos, dest, board);
	}

	return false;
}