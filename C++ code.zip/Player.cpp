#include "Player.h"

Player::Player(string n, Colour c)
{
	name = n;
	color = c;
}

string Player::getname()
{
	return name;

}
Colour Player::getcolor()
{
	return color;

}