#pragma once
#include "Piece.h"

class King : public Piece {
public:
    King(Position p, Colour c, Board* b);

    bool isLegal(Position dest) override;
    char draw() override;
    int getTextureID() override
    {
        if (color == cwhite)
            return 10;
        else 
            return 11;
    }
};
