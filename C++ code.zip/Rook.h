#pragma once
#include "Piece.h"
class Rook :public Piece
{

 public:
	Rook(Position p, Colour c, Board* b);
	bool isLegal(Position dest)override;
	char draw()override;
	int getTextureID() override
	{
		if (color == cwhite)
			return 2;
		else
			return 3;
	}
};

