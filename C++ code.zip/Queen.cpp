#include "Queen.h"
#include "Board.h"

Queen::Queen(Position p, Colour c, Board* b)
    : Piece(p, c, b) {}

char Queen::draw()
{
    if (color == cwhite)
    {
        return 'Q';
    }
    else
        return 'q';

}

bool Queen::isLegal(Position dest)
{
    if (isHorizontal(pos, dest))
        return isHorizontalpathclear(pos, dest, board);

    if (isVertical(pos, dest))
        return isVerticalpathclear(pos, dest, board);

    if (isDiagonal(pos, dest))
        return isDiagonalpathclear(pos, dest, board);

    return false;
}