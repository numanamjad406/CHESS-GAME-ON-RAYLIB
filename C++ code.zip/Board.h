#pragma once
#include "Piece.h"
#include "Pawn.h"
#include "Rook.h"
#include "Knight.h"
#include "Bishop.h"
#include "Queen.h"
#include "King.h"
#include "Player.h"

class Board
{

public:
    Piece* grid[8][8];

    Board();
    ~Board();

    void init();
    void displayBoard();

    Piece* pieceAt(Position p);
    bool update(Position src, Position dest);

    bool validateSource(Position src, Player current);
    bool validateDestination(Position dest, Player current);
    void drawPieces();

    void saveGame(const string& filename);
    void loadGame(const string& filename);
    string getState();
    void setState(string data);
};