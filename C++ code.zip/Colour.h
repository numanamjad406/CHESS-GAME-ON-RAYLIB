#pragma once
enum Colour { cblack, cwhite };

