#pragma once
#include "Piece.h"

class Queen : public Piece
{
public:
    Queen(Position p, Colour c, Board* b);

    bool isLegal(Position dest) override;
    char draw() override;
    int getTextureID() override
    {
        if (color == cwhite)
            return 8;
        else
            return  9;
    }
};